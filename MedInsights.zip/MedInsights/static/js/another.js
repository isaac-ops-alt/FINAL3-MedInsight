// Mock user data
const userName = "John Doe"; // Replace dynamically if needed

// Add event listener for the send button
document.getElementById("send-btn").addEventListener("click", handleUserMessage);

// Handle the user's input message
function handleUserMessage() {
  const userInput = document.getElementById("user-input").value;

  if (userInput.trim() !== "") {
    // Append user's message to the chat box
    appendMessage(userInput, "user");

    // Simulate AI response
    setTimeout(() => {
      handleAIResponse(userInput);
    }, 1000);

    // Clear the input field
    document.getElementById("user-input").value = "";
  }
}

// Append a message to the chat box
function appendMessage(message, sender) {
  const chatBox = document.getElementById("chat-box");

  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message", sender === "user" ? "user-message" : "bot-message");
  messageDiv.innerText = message;

  chatBox.appendChild(messageDiv);
  chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to the bottom
}

// Simulate AI response
function handleAIResponse(userInput) {
  let response;

  // AI logic based on user input
  if (userInput.toLowerCase().includes("hello")) {
    response = `Hi ${userName}, how are we feeling today?`;
  } else if (userInput.toLowerCase().includes("fever")) {
    response = "Please briefly describe how your body is responding or feeling.";
  } else {
    response = "Thank you for sharing. Here's some advice: stay hydrated and rest.";
  }

  // Append AI's response to the chat box
  appendMessage(response, "bot");
}
