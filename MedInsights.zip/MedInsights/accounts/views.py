from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.contrib.auth.models import User  # Import User model
from .forms import RegistrationForm

# Registration View
def register_view(request):
    if request.method == 'POST':
        # Get the form data from the POST request
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        # Check if the username already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
            return render(request, 'signup.html')

        # Check if the email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists!")
            return render(request, 'signup.html')

        # Create the user
        user = User.objects.create_user(username=username, email=email, password=password)
        
        # Log the user in immediately after registration
        login(request, user)
        
        # Success message and redirect to homepage
        messages.success(request, "Registration successful! You are now logged in.")
        return redirect('login')

    return render(request, 'signup.html')




def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']  # Get the username from the form
        password = request.POST['password']  # Get the password from the form

        # Authenticate the user
        user = authenticate(username=username, password=password)

        if user is not None:
            # Log the user in
            login(request, user)

            # Success message
            messages.success(request, f'Welcome back, {username}!')

            # Redirect to another page (e.g., 'home' or 'UI')
            return redirect('UI')  # Replace 'UI' with your desired URL pattern name
        else:
            # Invalid login
            messages.error(request, "Invalid username or password!")
            return render(request, 'login.html')  # Render the login page with an error message

    return render(request, 'login.html')  # Render the login page for GET requests
